//ciclo for
for (let i = 1; i <= 10; i++ )
{
    console.log ('El valor de i es: ' + i);

}

//ciclo while
let j = 1;
while(j <= 10)
{
    console.log('El valor de j es: '+ j);
    j++;
}

//ciclo do while
var k = 1;
do{
    console.log('El valor de k es: '+ k);
    k++;
}
while (k <= 10)