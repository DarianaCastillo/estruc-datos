//console.log('Hola mundo');

let edad = 2;

// Verificar si la ede es valida
if (edad > 0) {
    // Verificar si el usuario es mayor de 18
    if (edad >= 18) {
      console.log("Eres un adulto. Tienes " + edad + " años.");
    } else {
      console.log("Eres un niño. Tienes " + edad + " años.");
    }
  } else {
    console.log("Edad inválida. Ingresa un valor mayor que 0.");
  }

